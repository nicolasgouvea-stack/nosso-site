// Minimal frontend behavior: scrolling, modal, staff demo, appointment storage (localStorage)

document.addEventListener('DOMContentLoaded', ()=>{

  // smooth scroll
  document.querySelectorAll('[data-scroll]').forEach(btn=>{
    btn.addEventListener('click', ()=> {
      const id = btn.getAttribute('data-scroll');
      const el = document.getElementById(id);
      if(el) el.scrollIntoView({behavior:'smooth', block:'start'});
    })
  });

  // Hero buttons
  document.getElementById('btn-agendar-hero').addEventListener('click', ()=> openSection('agendar'));
  document.getElementById('btn-saber-mais').addEventListener('click', ()=> openSection('servicos'));

  function openSection(id){
    const el = document.getElementById(id);
    if(el) el.scrollIntoView({behavior:'smooth', block:'start'});
  }

  // Modal contato / dados pessoais
  const modal = document.getElementById('modal');
  const btnContact = document.getElementById('btn-contact');
  const modalClose = document.getElementById('modal-close');
  btnContact.addEventListener('click', ()=> { modal.setAttribute('aria-hidden','false'); });
  modalClose.addEventListener('click', ()=> { modal.setAttribute('aria-hidden','true'); });
  modal.addEventListener('click', (e)=>{ if(e.target === modal) modal.setAttribute('aria-hidden','true'); });

  // Save personal data locally
  const saveBtn = document.getElementById('save-dados');
  const clearDados = document.getElementById('clear-dados');
  const dadosSavedNotice = document.getElementById('dados-saved');

  saveBtn.addEventListener('click', ()=>{
    const data = {
      nome: document.getElementById('p_nome').value,
      dob: document.getElementById('p_dob').value,
      cpf: document.getElementById('p_cpf').value,
      end: document.getElementById('p_end').value,
      obs: document.getElementById('p_obs').value
    };
    localStorage.setItem('nutri_dados', JSON.stringify(data));
    dadosSavedNotice.hidden = false;
    setTimeout(()=>dadosSavedNotice.hidden = true, 2500);
  });
  clearDados.addEventListener('click', ()=>{
    localStorage.removeItem('nutri_dados');
    document.getElementById('p_nome').value='';
    document.getElementById('p_dob').value='';
    document.getElementById('p_cpf').value='';
    document.getElementById('p_end').value='';
    document.getElementById('p_obs').value='';
  });

  // Load saved dados if any
  const saved = localStorage.getItem('nutri_dados');
  if(saved){
    try{
      const obj = JSON.parse(saved);
      document.getElementById('p_nome').value = obj.nome || '';
      document.getElementById('p_dob').value = obj.dob || '';
      document.getElementById('p_cpf').value = obj.cpf || '';
      document.getElementById('p_end').value = obj.end || '';
      document.getElementById('p_obs').value = obj.obs || '';
    }catch(e){}
  }

  // Staff demo: add sample staff and support adding more (demo only)
  const teamGrid = document.getElementById('team-grid');
  const addStaffBtn = document.getElementById('btn-add-staff');

  const sampleStaff = [
    {name:'Dra. Ana Silva', role:'Nutricionista clínica', bio:'Especialista em nutrição funcional e emagrecimento.'},
    {name:'Dr. João Pereira', role:'Nutricionista esportivo', bio:'Foco em performance e composição corporal.'},
    {name:'Larissa Costa', role:'Assistente', bio:'Atendimento e suporte de pacientes.'}
  ];

  function renderStaff(list){
    teamGrid.innerHTML = '';
    list.forEach((s, idx)=>{
      const div = document.createElement('div'); div.className='staff';
      div.innerHTML = `<div class="avatar" aria-hidden="true">${String.fromCharCode(65+idx)}</div>
        <div>
          <h5>${s.name}</h5>
          <p>${s.role}</p>
          <small style="color:var(--muted)">${s.bio}</small>
        </div>`;
      teamGrid.appendChild(div);
    });
  }
  renderStaff(sampleStaff);

  addStaffBtn.addEventListener('click', ()=>{
    const name = prompt('Nome do funcionário (demo)');
    if(!name) return;
    sampleStaff.push({name, role:'Função não informada', bio:'Descrição curta.'});
    renderStaff(sampleStaff);
  });

  // Agenda: save to localStorage, list, remove
  const formAgenda = document.getElementById('form-agenda');
  const lista = document.getElementById('lista-agendamentos');
  const limparBtn = document.getElementById('btn-limpar');

  function loadAgendas(){
    const raw = localStorage.getItem('nutri_agendas');
    let arr = [];
    try{ arr = raw ? JSON.parse(raw) : []; }catch(e){ arr=[]; }
    return arr;
  }
  function saveAgendas(arr){ localStorage.setItem('nutri_agendas', JSON.stringify(arr)); }

  function renderAgendas(){
    const arr = loadAgendas();
    if(arr.length===0){ lista.innerHTML = '<li>Nenhum agendamento.</li>'; return; }
    lista.innerHTML = '';
    arr.forEach((a, i)=>{
      const li = document.createElement('li');
      li.innerHTML = `<strong>${a.nome}</strong> — ${a.data} ${a.hora} (${a.tipo}) <br><small style="color:var(--muted)">${a.email} · ${a.telefone}</small>
        <div style="margin-top:6px"><button data-idx="${i}" class="rem">Cancelar</button></div>`;
      lista.appendChild(li);
    });
    lista.querySelectorAll('.rem').forEach(btn=>{
      btn.addEventListener('click', (e)=>{
        const idx = Number(btn.getAttribute('data-idx'));
        const arr = loadAgendas();
        arr.splice(idx,1);
        saveAgendas(arr);
        renderAgendas();
      });
    });
  }
  renderAgendas();

  formAgenda.addEventListener('submit', (e)=>{
    e.preventDefault();
    const obj = {
      nome: document.getElementById('nome').value,
      email: document.getElementById('email').value,
      telefone: document.getElementById('telefone').value,
      tipo: document.getElementById('tipo').value,
      data: document.getElementById('data').value,
      hora: document.getElementById('hora').value,
      obs: document.getElementById('obs').value
    };
    // simple validation: date >= today
    const today = new Date(); today.setHours(0,0,0,0);
    const selected = new Date(obj.data + 'T00:00:00');
    if(selected < today){ alert('Favor escolher uma data válida (hoje ou futuro).'); return; }
    const arr = loadAgendas();
    arr.push(obj);
    saveAgendas(arr);
    renderAgendas();
    formAgenda.reset();
    alert('Agendamento salvo localmente. Para produção, implemente envio ao servidor.');
  });

  limparBtn.addEventListener('click', ()=>{ if(confirm('Limpar todos os agendamentos locais?')){ localStorage.removeItem('nutri_agendas'); renderAgendas(); } });

});
