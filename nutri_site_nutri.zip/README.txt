README - NutriFuturo (demo)
===========================
Conteúdo: site estático (demo) com:
 - index.html
 - styles.css
 - script.js

Características:
 - Design moderno/futurista.
 - Botões funcionando (navegação interna, modal).
 - Área para salvar dados pessoais no armazenamento local do navegador.
 - Formulário de agendamento que guarda agendamentos no localStorage (demo).
 - Galeria/área para fotos da equipe (cards com avatars).
 - Muitas seções com informações de nutrição.

Observações importantes:
 - Este é um site estático (front-end). Para disponibilizar em produção e receber formulários/agenda no servidor, é necessário implementar um backend (ex.: PHP, Node.js, Firebase).
 - As imagens de staff são placeholders; substitua por fotos reais nas pastas apropriadas.
 - Para personalizar, edite os arquivos e abra index.html no navegador.

Como usar:
 1. Baixe o ZIP e extraia.
 2. Abra index.html no navegador.
 3. Em produção, hospede os arquivos em um servidor ou serviço de hospedagem estática (Netlify, Vercel, GitHub Pages, etc.).
